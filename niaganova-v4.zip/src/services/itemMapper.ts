import { InventoryItem } from '../types/inventory';

/**
 * Fungsi murni (tanpa Firebase) untuk mengubah data aplikasi <-> dokumen Firestore.
 * Dipisahkan agar mudah diuji dan agar payload SELALU lolos validasi firestore.rules.
 */

const ID_PATTERN = /^[a-zA-Z0-9_-]{1,128}$/;

export const isValidItemId = (id: unknown): id is string => typeof id === 'string' && ID_PATTERN.test(id);

const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

const str = (v: unknown, max: number): string => String(v ?? '').slice(0, max);

/** Ubah barang aplikasi menjadi dokumen Firestore yang valid (tanpa nilai undefined). */
export function toItemDoc(item: InventoryItem, uid: string): Record<string, unknown> {
  if (!isValidItemId(item.id)) {
    throw new Error(`ID barang tidak valid: "${String(item.id).slice(0, 40)}"`);
  }
  const now = Date.now();
  const doc: Record<string, unknown> = {
    id: item.id,
    userId: uid,
    namaBarang: str(item.namaBarang, 256).trim() || 'Tanpa nama',
    satuanWadah: str(item.satuanWadah, 64),
    jumlahBarangWadah: num(item.jumlahBarangWadah),
    satuanUnit: str(item.satuanUnit, 64),
    hargaBeli: num(item.hargaBeli),
    jumlahBarangDijualSatuan: num(item.jumlahBarangDijualSatuan),
    hargaJualSatuan: num(item.hargaJualSatuan),
    persentaseLabaDisimpanBulanan: num(item.persentaseLabaDisimpanBulanan, 50),
    createdAt: num(item.createdAt, now),
    updatedAt: now,
  };
  if (item.perputaranBulan !== undefined && item.perputaranBulan !== null) {
    doc.perputaranBulan = num(item.perputaranBulan);
  }
  if (item.tanggalInput) doc.tanggalInput = str(item.tanggalInput, 32);
  if (item.waktuInput) doc.waktuInput = str(item.waktuInput, 32);
  if (item.catatan) doc.catatan = str(item.catatan, 512);
  return doc;
}

/** Ubah dokumen Firestore menjadi barang aplikasi (dengan nilai bawaan aman). */
export function fromItemDoc(d: Record<string, any>, fallbackId: string): InventoryItem {
  return {
    id: d.id || fallbackId,
    namaBarang: d.namaBarang ?? '',
    satuanWadah: d.satuanWadah ?? '',
    jumlahBarangWadah: num(d.jumlahBarangWadah),
    satuanUnit: d.satuanUnit ?? '',
    hargaBeli: num(d.hargaBeli),
    jumlahBarangDijualSatuan: num(d.jumlahBarangDijualSatuan),
    hargaJualSatuan: num(d.hargaJualSatuan),
    persentaseLabaDisimpanBulanan: num(d.persentaseLabaDisimpanBulanan, 50),
    perputaranBulan: d.perputaranBulan,
    tanggalInput: d.tanggalInput,
    waktuInput: d.waktuInput,
    catatan: d.catatan,
    createdAt: num(d.createdAt, Date.now()),
    updatedAt: num(d.updatedAt, Date.now()),
  };
}

/** Bagian-bagian barang yang boleh diubah lewat update parsial. */
export function toItemPatch(patch: Partial<InventoryItem>): Record<string, unknown> {
  const out: Record<string, unknown> = { updatedAt: Date.now() };
  const numericKeys = [
    'jumlahBarangWadah',
    'hargaBeli',
    'jumlahBarangDijualSatuan',
    'hargaJualSatuan',
    'persentaseLabaDisimpanBulanan',
    'perputaranBulan',
  ] as const;
  for (const k of numericKeys) {
    if (patch[k] !== undefined) out[k] = num(patch[k]);
  }
  if (patch.namaBarang !== undefined) out.namaBarang = str(patch.namaBarang, 256).trim() || 'Tanpa nama';
  if (patch.satuanWadah !== undefined) out.satuanWadah = str(patch.satuanWadah, 64);
  if (patch.satuanUnit !== undefined) out.satuanUnit = str(patch.satuanUnit, 64);
  if (patch.tanggalInput !== undefined) out.tanggalInput = str(patch.tanggalInput, 32);
  if (patch.waktuInput !== undefined) out.waktuInput = str(patch.waktuInput, 32);
  if (patch.catatan !== undefined) out.catatan = str(patch.catatan, 512);
  return out;
}

/** Firestore membatasi 500 operasi per batch. */
export function chunk<T>(arr: T[], size = 400): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/**
 * Pastikan setiap barang punya id valid & unik (data dari file cadangan bisa berisi id lain).
 * Dipakai sebelum data ditampilkan DAN disimpan, agar id di layar = id di Firestore.
 */
export function normalizeItems(items: InventoryItem[]): InventoryItem[] {
  const seen = new Set<string>();
  const now = Date.now();
  return items.map((it, idx) => {
    let id = isValidItemId(it.id) && !seen.has(it.id) ? it.id : '';
    if (!id) {
      do {
        id = `item_${now}_${idx}_${Math.random().toString(36).substring(2, 7)}`;
      } while (seen.has(id));
    }
    seen.add(id);
    return {
      ...it,
      id,
      namaBarang: str(it.namaBarang, 256).trim() || 'Tanpa nama',
      satuanWadah: str(it.satuanWadah, 64),
      satuanUnit: str(it.satuanUnit, 64),
      jumlahBarangWadah: num(it.jumlahBarangWadah),
      hargaBeli: num(it.hargaBeli),
      jumlahBarangDijualSatuan: num(it.jumlahBarangDijualSatuan),
      hargaJualSatuan: num(it.hargaJualSatuan),
      persentaseLabaDisimpanBulanan: num(it.persentaseLabaDisimpanBulanan, 50),
      createdAt: num(it.createdAt, now),
      updatedAt: num(it.updatedAt, now),
    };
  });
}
