import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { X, Mail, Lock, ShieldCheck, CheckCircle2, AlertCircle, Loader2, Database } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onSuccess?: () => void;
  /** true = layar login wajib (tanpa tombol tutup), dipakai saat belum login */
  required?: boolean;
}

// Terjemahkan kode error Firebase menjadi pesan yang mudah dipahami
function friendlyAuthError(err: unknown): string {
  const code = (err as any)?.code as string | undefined;
  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return 'Jendela login Google ditutup sebelum selesai. Silakan coba lagi.';
    case 'auth/popup-blocked':
      return 'Popup login Google diblokir browser. Izinkan popup, atau masuk lewat tab "Email & Sandi".';
    case 'auth/unauthorized-domain':
      return 'Domain situs ini belum diizinkan untuk login Google. Tambahkan di Firebase Console > Authentication > Settings > Authorized domains, atau masuk lewat tab "Email & Sandi".';
    case 'auth/operation-not-supported-in-this-environment':
      return 'Login Google tidak didukung di lingkungan ini (mis. pratinjau dalam iframe). Masuk lewat tab "Email & Sandi".';
    case 'auth/operation-not-allowed':
      return 'Metode login ini belum diaktifkan di Firebase Console > Authentication > Sign-in method.';
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Email atau kata sandi salah.';
    case 'auth/email-already-in-use':
      return 'Email ini sudah terdaftar. Silakan pilih "Masuk".';
    case 'auth/invalid-email':
      return 'Format email tidak valid.';
    case 'auth/weak-password':
      return 'Kata sandi terlalu lemah (minimal 6 karakter).';
    case 'auth/account-exists-with-different-credential':
      return 'Email ini sudah terdaftar dengan metode login lain. Coba metode lain (Google atau Email & Sandi).';
    case 'auth/too-many-requests':
      return 'Terlalu banyak percobaan. Tunggu beberapa menit lalu coba lagi.';
    case 'auth/network-request-failed':
      return 'Koneksi internet bermasalah. Periksa jaringan Anda.';
    default:
      return err instanceof Error ? err.message : 'Terjadi kesalahan saat login.';
  }
}

export function AuthModal({ isOpen, onClose, onSuccess, required = false }: AuthModalProps) {
  const { signInWithGoogle, signInWithEmail, signUpWithEmail, resetPassword } = useAuth();
  const [authMode, setAuthMode] = useState<'google' | 'email'>('google');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const finish = () => {
    onSuccess?.();
    onClose?.();
  };

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      finish();
    } catch (err) {
      setErrorMsg(friendlyAuthError(err));
      const code = (err as any)?.code;
      if (code === 'auth/unauthorized-domain' || code === 'auth/operation-not-supported-in-this-environment' || code === 'auth/popup-blocked') {
        setAuthMode('email');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!email) {
      setErrorMsg('Isi alamat email Anda dulu, lalu klik "Lupa kata sandi?".');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    setInfoMsg(null);
    try {
      await resetPassword(email);
      setInfoMsg('Jika email terdaftar, tautan untuk mengatur ulang kata sandi sudah dikirim. Periksa kotak masuk (dan folder spam).');
    } catch (err) {
      setErrorMsg(friendlyAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('Mohon isi email dan kata sandi');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Kata sandi minimal 6 karakter');
      return;
    }
    setIsLoading(true);
    setErrorMsg(null);
    try {
      if (isRegisterMode) await signUpWithEmail(email, password);
      else await signInWithEmail(email, password);
      finish();
    } catch (err) {
      setErrorMsg(friendlyAuthError(err));
    } finally {
      setIsLoading(false);
    }
  };

  const GoogleIcon = ({ className }: { className: string }) => (
    <svg className={className} viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
    </svg>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-md bg-slate-900 rounded-3xl shadow-2xl border border-slate-700/80 overflow-hidden text-slate-100 animate-in zoom-in-95 duration-150">
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 p-6 text-white text-center relative border-b border-slate-800">
          {!required && onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          <div className="inline-flex p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-2xl backdrop-blur-md mb-2 shadow-inner">
            <GoogleIcon className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white font-sans">
            {required ? 'Masuk ke NiagaNova' : 'Masuk dengan Akun Google'}
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto font-mono">
            Login & penyimpanan data satu tempat: Firebase
          </p>
        </div>

        <div className="p-6 space-y-4">
          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-xs text-slate-300 flex items-start gap-2.5 font-mono">
            <Database className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white block">Aman walau browser dibersihkan</span>
              Data tersimpan di cloud (Firebase) dan terikat ke akun Anda. Login lagi di perangkat mana pun untuk melihatnya.
            </div>
          </div>

          {infoMsg && (
            <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-start gap-2 font-mono">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <span>{infoMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-xs text-rose-300 flex items-start gap-2 font-mono">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800 font-mono text-xs">
            {(['google', 'email'] as const).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => {
                  setAuthMode(mode);
                  setErrorMsg(null);
                }}
                className={`flex-1 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  authMode === mode ? 'bg-emerald-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                {mode === 'google' ? 'Akun Google' : 'Email & Sandi'}
              </button>
            ))}
          </div>

          {authMode === 'google' && (
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 p-3.5 border-2 border-emerald-500/50 bg-emerald-950/30 hover:bg-emerald-950/50 hover:border-emerald-400 rounded-2xl transition-all cursor-pointer shadow-lg shadow-emerald-950/40 disabled:opacity-50"
            >
              <div className="w-8 h-8 rounded-lg bg-white p-1.5 flex items-center justify-center shrink-0">
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin text-slate-700" /> : <GoogleIcon className="w-5 h-5" />}
              </div>
              <span className="text-sm font-bold text-white font-sans">Lanjutkan dengan Google</span>
            </button>
          )}

          {authMode === 'email' && (
            <form onSubmit={handleEmailAuth} className="space-y-3 font-mono">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Alamat Email</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nama@email.com"
                    required
                    autoComplete="email"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Kata Sandi</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimal 6 karakter"
                    required
                    autoComplete={isRegisterMode ? 'new-password' : 'current-password'}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Memproses...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 stroke-[3]" />
                    <span>{isRegisterMode ? 'Daftar Akun Baru' : 'Masuk'}</span>
                  </>
                )}
              </button>
              {!isRegisterMode && (
                <div className="text-right">
                  <button
                    type="button"
                    onClick={handleResetPassword}
                    disabled={isLoading}
                    className="text-[11px] text-slate-400 hover:text-emerald-300 cursor-pointer underline underline-offset-4 disabled:opacity-50"
                  >
                    Lupa kata sandi?
                  </button>
                </div>
              )}
              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegisterMode(!isRegisterMode);
                    setErrorMsg(null);
                    setInfoMsg(null);
                  }}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-medium cursor-pointer underline underline-offset-4"
                >
                  {isRegisterMode ? 'Sudah punya akun? Masuk di sini' : 'Belum punya akun? Buat akun baru'}
                </button>
              </div>
            </form>
          )}

          <div className="pt-2 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center gap-1.5 justify-center">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Setiap akun hanya bisa melihat datanya sendiri</span>
          </div>
        </div>
      </div>
    </div>
  );
}
