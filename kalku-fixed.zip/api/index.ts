import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { MongoClient, ServerApiVersion, Db } from 'mongodb';

dotenv.config();

/**
 * Backend NiagaNova (Express).
 * - Di Vercel: diekspor sebagai Vercel Function lewat api/index.ts (lihat vercel.json).
 * - Lokal   : dipasang oleh server.ts bersama Vite dev server.
 * Semua kode backend sengaja ada di satu file ini supaya bundling Vercel tidak bergantung pada import relatif.
 */

const IS_VERCEL = !!process.env.VERCEL;
const MONGODB_URI = process.env.MONGODB_URI || '';
const DB_NAME = process.env.MONGODB_DB_NAME || 'niaganova_db';

// ---------- MongoDB connection (di-cache antar invocation) ----------
let client: MongoClient | null = null;
let db: Db | null = null;
let isConnected = false;
let lastError: string | null = null;
let needsIpWhitelist = false;
let connectingPromise: Promise<{ client: MongoClient; db: Db } | null> | null = null;

export async function connectToDatabase(): Promise<{ client: MongoClient; db: Db } | null> {
  if (db && isConnected) return { client: client!, db };
  if (connectingPromise) return connectingPromise;

  connectingPromise = (async () => {
    try {
      if (!MONGODB_URI) {
        throw new Error('Environment variable MONGODB_URI belum diisi.');
      }
      if (!client) {
        client = new MongoClient(MONGODB_URI, {
          serverApi: { version: ServerApiVersion.v1, strict: true, deprecationErrors: true },
          connectTimeoutMS: 8000,
          serverSelectionTimeoutMS: 8000,
          socketTimeoutMS: 20000,
          maxPoolSize: 5,
        });
      }
      await client.connect();
      db = client.db(DB_NAME);
      await db.command({ ping: 1 });
      isConnected = true;
      lastError = null;
      needsIpWhitelist = false;
      console.log(`[MongoDB Atlas] Connected to database: ${DB_NAME}`);

      try {
        await db.collection('inventory_items').createIndex({ id: 1 }, { unique: true });
      } catch (idxErr) {
        console.warn('[MongoDB Atlas] Index creation:', idxErr);
      }
      return { client: client!, db: db! };
    } catch (err: any) {
      isConnected = false;
      db = null;
      const msg = err?.message || String(err);
      lastError = msg;
      // Buang client yang gagal supaya percobaan berikutnya mulai dari awal
      try { await client?.close(); } catch { /* ignore */ }
      client = null;

      if (/SSL alert number 80|tlsv1 alert internal error|whitelist|ETIMEDOUT|Server selection timed out/i.test(msg)) {
        needsIpWhitelist = true;
        console.warn('[MongoDB Atlas] Koneksi gagal. Pastikan 0.0.0.0/0 diizinkan di Atlas > Network Access.');
      } else {
        console.error('[MongoDB Atlas] Connection error:', msg);
      }
      return null;
    } finally {
      connectingPromise = null;
    }
  })();

  return connectingPromise;
}

// Auto-reconnect hanya untuk server long-running (lokal). Di serverless tidak dipakai.
if (!IS_VERCEL) {
  setInterval(async () => {
    if (!isConnected) await connectToDatabase();
  }, 10000).unref();
}

export function getDatabaseStatus() {
  return {
    connected: isConnected,
    dbName: DB_NAME,
    error: lastError,
    needsIpWhitelist,
    uriMasked: MONGODB_URI ? MONGODB_URI.replace(/:([^@]+)@/, ':****@') : '(MONGODB_URI belum diisi)',
  };
}

export async function getDbInstance(): Promise<Db | null> {
  if (db && isConnected) return db;
  const conn = await connectToDatabase();
  return conn ? conn.db : null;
}

// ---------- Express app ----------
const __dirname_safe = process.cwd();
const DATA_DIR = path.resolve(__dirname_safe, 'data');
const BACKUP_FILE = path.resolve(DATA_DIR, 'store_backup.json');

// Fallback file lokal hanya dipakai di luar Vercel (filesystem Vercel read-only)
if (!IS_VERCEL) {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.error('Failed to create data dir:', e);
  }
}

export const app = express();
app.use(express.json({ limit: '10mb' }));

// Respon 503 yang jelas jika database belum terhubung (jangan pura-pura sukses)
function dbUnavailable(res: express.Response) {
  const st = getDatabaseStatus();
  let message = `Database MongoDB Atlas belum terhubung: ${st.error || 'alasan tidak diketahui'}.`;
  if (!MONGODB_URI) {
    message = 'MONGODB_URI belum diatur di server. Isi di Vercel > Settings > Environment Variables, lalu redeploy.';
  } else if (st.needsIpWhitelist) {
    message += ' Izinkan 0.0.0.0/0 di MongoDB Atlas > Network Access.';
  }
  return res.status(503).json({ success: false, message });
}

// 1. Status koneksi MongoDB Atlas
app.get('/api/db/status', async (_req, res) => {
  if (!isConnected) await connectToDatabase();
  return res.status(200).json(getDatabaseStatus());
});

// 2. Ambil semua barang + pengaturan
app.get('/api/inventory', async (_req, res) => {
  try {
    const database = await getDbInstance();

    if (database) {
      const items = await database.collection('inventory_items').find({}).sort({ createdAt: -1 }).toArray();
      const settings = await database.collection('settings').findOne({ _id: 'app_settings' as any });
      const sanitizedItems = items.map((doc: any) => {
        const { _id, ...rest } = doc;
        return rest;
      });
      return res.status(200).json({
        success: true,
        source: 'mongodb-atlas',
        items: sanitizedItems,
        modalAwal: settings?.modalAwal ?? 50000,
        globalSavePercentMonthly: settings?.globalSavePercentMonthly ?? 50,
      });
    }

    // Di Vercel tidak ada fallback file: laporkan error, jangan kirim data kosong palsu
    if (IS_VERCEL) return dbUnavailable(res);

    if (fs.existsSync(BACKUP_FILE)) {
      const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
      return res.status(200).json({
        success: true,
        source: 'local-fallback',
        items: data.items || [],
        modalAwal: data.modalAwal ?? 50000,
        globalSavePercentMonthly: data.globalSavePercentMonthly ?? 50,
      });
    }

    return res.status(200).json({
      success: true,
      source: 'empty',
      items: [],
      modalAwal: 50000,
      globalSavePercentMonthly: 50,
    });
  } catch (err: any) {
    console.error('Error fetching inventory:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 3. Simpan / upsert satu barang
app.post('/api/inventory/item', async (req, res) => {
  try {
    const item = req.body;
    if (!item || !item.id) {
      return res.status(400).json({ success: false, message: 'Item id is required' });
    }
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    await database.collection('inventory_items').updateOne(
      { id: item.id },
      { $set: { ...item, updatedAt: Date.now() } },
      { upsert: true }
    );
    syncToFileFallback(item, 'upsert');
    return res.status(200).json({ success: true, message: 'Item saved to MongoDB Atlas', item });
  } catch (err: any) {
    console.error('Error saving item:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 4. Update satu barang
app.put('/api/inventory/item/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    await database.collection('inventory_items').updateOne(
      { id },
      { $set: { ...req.body, updatedAt: Date.now() } }
    );
    return res.status(200).json({ success: true, message: 'Item updated in MongoDB Atlas' });
  } catch (err: any) {
    console.error('Error updating item:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 5. Hapus satu barang
app.delete('/api/inventory/item/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) return res.status(400).json({ success: false, message: 'Item id is required' });

    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    const result = await database.collection('inventory_items').deleteOne({ id });
    console.log(`[MongoDB Atlas] Deleted item id: ${id}, count: ${result.deletedCount}`);
    syncToFileFallback({ id }, 'delete');
    return res.status(200).json({ success: true, message: 'Item deleted from MongoDB Atlas' });
  } catch (err: any) {
    console.error('Error deleting item:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 6. Hapus semua barang
app.delete('/api/inventory/clear', async (_req, res) => {
  try {
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    const result = await database.collection('inventory_items').deleteMany({});
    console.log(`[MongoDB Atlas] Cleared all items, count: ${result.deletedCount}`);

    if (!IS_VERCEL && fs.existsSync(BACKUP_FILE)) {
      try {
        const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
        data.items = [];
        fs.writeFileSync(BACKUP_FILE, JSON.stringify(data, null, 2), 'utf-8');
      } catch (e) {
        console.error(e);
      }
    }
    return res.status(200).json({ success: true, message: 'All items deleted from MongoDB Atlas' });
  } catch (err: any) {
    console.error('Error clearing items:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 7. Simpan pengaturan (Modal Awal & Save %)
app.post('/api/inventory/settings', async (req, res) => {
  try {
    const { modalAwal, globalSavePercentMonthly } = req.body;
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    const updates: any = { updatedAt: Date.now() };
    if (typeof modalAwal === 'number') updates.modalAwal = modalAwal;
    if (typeof globalSavePercentMonthly === 'number') updates.globalSavePercentMonthly = globalSavePercentMonthly;

    await database.collection('settings').updateOne(
      { _id: 'app_settings' as any },
      { $set: updates },
      { upsert: true }
    );
    return res.status(200).json({ success: true, message: 'Settings saved to MongoDB Atlas' });
  } catch (err: any) {
    console.error('Error saving settings:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 8. Batch restore (ganti semua data)
app.post('/api/inventory/batch', async (req, res) => {
  try {
    const { items, modalAwal, globalSavePercentMonthly } = req.body;
    if (!Array.isArray(items)) {
      return res.status(400).json({ success: false, message: 'Invalid items array' });
    }
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    const itemsCollection = database.collection('inventory_items');
    await itemsCollection.deleteMany({});
    if (items.length > 0) {
      await itemsCollection.insertMany(items.map((i: any) => ({ ...i })));
    }

    const updates: any = { updatedAt: Date.now() };
    if (typeof modalAwal === 'number') updates.modalAwal = modalAwal;
    if (typeof globalSavePercentMonthly === 'number') updates.globalSavePercentMonthly = globalSavePercentMonthly;
    await database.collection('settings').updateOne(
      { _id: 'app_settings' as any },
      { $set: updates },
      { upsert: true }
    );
    return res.status(200).json({ success: true, message: 'Batch restored successfully in MongoDB Atlas' });
  } catch (err: any) {
    console.error('Error in batch restore:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// 9. Impor massal (mode 'append' atau 'replace')
app.post('/api/inventory/import', async (req, res) => {
  try {
    const { items, mode = 'append', modalAwal } = req.body;
    if (!Array.isArray(items)) {
      return res.status(400).json({ success: false, message: 'Invalid items array' });
    }
    const database = await getDbInstance();
    if (!database) return dbUnavailable(res);

    const itemsCollection = database.collection('inventory_items');
    if (mode === 'replace') await itemsCollection.deleteMany({});

    if (items.length > 0) {
      await itemsCollection.bulkWrite(
        items.map((item: any) => ({
          updateOne: { filter: { id: item.id }, update: { $set: item }, upsert: true },
        }))
      );
    }

    if (typeof modalAwal === 'number' && modalAwal >= 0) {
      await database.collection('settings').updateOne(
        { _id: 'app_settings' as any },
        { $set: { modalAwal, updatedAt: Date.now() } },
        { upsert: true }
      );
    }

    return res.status(200).json({
      success: true,
      message: `Berhasil mengimpor ${items.length} barang ke MongoDB Atlas`,
      count: items.length,
      mode,
    });
  } catch (err: any) {
    console.error('Error importing items:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
});

// Semua /api/* yang tidak dikenal -> JSON 404 (bukan HTML), supaya frontend selalu dapat JSON
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: `Endpoint tidak ditemukan: ${req.method} ${req.originalUrl}` });
});

// Error handler terakhir (mis. body JSON terlalu besar / rusak)
app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  const status = err?.status || err?.statusCode || 500;
  res.status(status).json({ success: false, message: err?.message || 'Internal server error' });
});

// Fallback file lokal (hanya dev lokal)
function syncToFileFallback(item: any, action: 'upsert' | 'delete') {
  if (IS_VERCEL) return;
  try {
    let currentData = { items: [] as any[], modalAwal: 50000 };
    if (fs.existsSync(BACKUP_FILE)) {
      currentData = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
    }
    if (!Array.isArray(currentData.items)) currentData.items = [];

    if (action === 'upsert') {
      const idx = currentData.items.findIndex((i: any) => i.id === item.id);
      if (idx >= 0) currentData.items[idx] = item;
      else currentData.items.unshift(item);
    } else {
      currentData.items = currentData.items.filter((i: any) => i.id !== item.id);
    }
    fs.writeFileSync(BACKUP_FILE, JSON.stringify(currentData, null, 2), 'utf-8');
  } catch (e) {
    console.error('File fallback error:', e);
  }
}

// Vercel Function: Express app adalah handler (req, res)
export default app;
