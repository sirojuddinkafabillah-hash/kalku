import { InventoryItem } from '../types/inventory';

export interface BackupPayload {
  version: number;
  appName: string;
  exportedAt: string;
  modalAwal: number;
  items: InventoryItem[];
}

// Generate JSON download file
export function exportBackupJSON(items: InventoryItem[], modalAwal: number): void {
  const payload: BackupPayload = {
    version: 1,
    appName: 'Kalkulator Dagang & Arus Kas',
    exportedAt: new Date().toISOString(),
    modalAwal,
    items,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().slice(0, 10);
  a.download = `cadangan_toko_${dateStr}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Parse imported JSON backup
export function parseBackupJSON(jsonString: string): { items: InventoryItem[]; modalAwal: number } {
  const data = JSON.parse(jsonString);
  let items: InventoryItem[] = [];
  let modalAwal = 50000;

  if (Array.isArray(data)) {
    items = data;
  } else if (data && typeof data === 'object') {
    if (Array.isArray(data.items)) {
      items = data.items;
    }
    if (typeof data.modalAwal === 'number' && !isNaN(data.modalAwal)) {
      modalAwal = data.modalAwal;
    }
  }

  // Sanitize items
  const validItems = items.filter((it) => it && typeof it.namaBarang === 'string');
  return { items: validItems, modalAwal };
}
