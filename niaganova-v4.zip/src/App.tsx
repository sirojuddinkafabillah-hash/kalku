import React, { useState, useEffect, useMemo } from 'react';
import { InventoryItem } from './types/inventory';
import { calculateSummary } from './utils/calculator';
import { Header, AppPage } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { QuickAddBar } from './components/QuickAddBar';
import { InventoryTable } from './components/InventoryTable';
import { ItemModal } from './components/ItemModal';
import { CashFlowGuideModal } from './components/CashFlowGuideModal';
import { DownloadModal } from './components/DownloadModal';
import { PrintReportView } from './components/PrintReportView';
import { AuthModal } from './components/AuthModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ReportsEquityPage } from './components/ReportsEquityPage';
import { ImportDataPage } from './components/ImportDataPage';
import { CosmicInteractiveBackground, BackgroundTheme } from './components/CosmicInteractiveBackground';
import { useAuth } from './context/AuthContext';
import { 
  Cloud, 
  CheckCircle2, 
  ShieldCheck, 
  HelpCircle, 
  RefreshCw,
  Database,
  AlertCircle,
  TrendingUp,
  UploadCloud
} from 'lucide-react';
import {
  fetchInventoryFromCloud,
  saveItemToCloud,
  updateItemInCloud,
  deleteItemFromCloud,
  clearAllItemsFromCloud,
  saveSettingsToCloud,
  batchRestoreToCloud,
} from './services/cloudStore';
import { normalizeItems } from './services/itemMapper';

function AppContent() {
  const { user } = useAuth();

  // App Core State (dimuat langsung dari Firebase Firestore, per akun)
  const [modalAwal, setModalAwal] = useState<number>(50000);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [globalSavePercentMonthly, setGlobalSavePercentMonthly] = useState<number>(50);

  // Database status
  const [isCloudLoading, setIsCloudLoading] = useState<boolean>(true);
  const [isSavingCloud, setIsSavingCloud] = useState<boolean>(false);
  const [notification, setNotification] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Real-time ticking clock
  const [currentRealTime, setCurrentRealTime] = useState<string>(() => {
    return new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentRealTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // UI Modals
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<string>('all');

  // Active Navigation Page (Kasir & Inventori, Laporan & Ekuitas, Impor Data)
  const [activePage, setActivePage] = useState<AppPage>('inventory');

  // Delete Confirmation State (Replaces window.confirm)
  const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);
  const [isConfirmClearAllOpen, setIsConfirmClearAllOpen] = useState<boolean>(false);

  // Background Theme
  const [backgroundTheme, setBackgroundTheme] = useState<BackgroundTheme>(() => {
    try {
      const stored = localStorage.getItem('niaganova_bg_theme');
      if (stored && ['cosmic-nebula', 'aurora-emerald', 'cyber-sapphire', 'light-crystal'].includes(stored)) {
        return stored as BackgroundTheme;
      }
    } catch (e) {
      console.error(e);
    }
    return 'cosmic-nebula';
  });

  const handleThemeChange = (theme: BackgroundTheme) => {
    setBackgroundTheme(theme);
    try {
      localStorage.setItem('niaganova_bg_theme', theme);
    } catch (e) {
      console.error(e);
    }
  };

  // Auto-dismiss notifications after 5 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // 1. Muat data akun dari Firebase Firestore (bukan localStorage)
  const loadCloudData = async () => {
    setIsCloudLoading(true);
    try {
      // Bersihkan sisa kunci localStorage versi lama agar data hanya bersumber dari cloud
      try {
        const legacyKeys = [
          'kalkulator_penjualan_rolling_items',
          'kalkulator_penjualan_monthly_items',
          'kalkulator_penjualan_simple_items',
          'kalkulator_dagang_items_v1',
          'kalkulator_penjualan_modal_awal'
        ];
        for (const k of legacyKeys) {
          localStorage.removeItem(k);
        }
      } catch (e) {
        console.warn('LocalStorage cleanup:', e);
      }

      const inv = await fetchInventoryFromCloud();
      setItems(inv.items);
      setModalAwal(inv.modalAwal);
      setGlobalSavePercentMonthly(inv.globalSavePercentMonthly);
      setLoadError(null);
      setNotification(`Data akun Anda berhasil dimuat (${inv.items.length} barang).`);
    } catch (err) {
      console.error('Error loading from Firestore:', err);
      setLoadError(
        (err instanceof Error ? err.message : 'Terjadi kesalahan saat memuat data.') +
          ' Jangan menambah atau mengimpor data dulu sebelum data berhasil dimuat.'
      );
    } finally {
      setIsCloudLoading(false);
    }
  };

  useEffect(() => {
    loadCloudData();
  }, []);

  // Filtered items by selected month
  const filteredMonthlyItems = useMemo(() => {
    if (selectedMonth === 'all') return items;
    return items.filter((item) => {
      const itemMonth = (item.tanggalInput || new Date(item.createdAt).toISOString().slice(0, 7)).slice(0, 7);
      return itemMonth === selectedMonth;
    });
  }, [items, selectedMonth]);

  // Overall financial summary
  const summary = useMemo(() => {
    return calculateSummary(filteredMonthlyItems, modalAwal);
  }, [filteredMonthlyItems, modalAwal]);

  // Handlers for Items dengan penyimpanan Firebase Firestore
  const handleAddItem = async (newItemData: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = Date.now();
    const item: InventoryItem = {
      ...newItemData,
      id: `item_${now}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: now,
      updatedAt: now,
      persentaseLabaDisimpanBulanan: newItemData.persentaseLabaDisimpanBulanan ?? globalSavePercentMonthly,
    };

    // Immediate optimistic update
    setItems((prev) => [item, ...prev]);

    // Simpan ke Firestore; jika gagal, batalkan penambahan di layar agar tidak ada data "hantu"
    setIsSavingCloud(true);
    try {
      const ok = await saveItemToCloud(item);
      if (ok) {
        setNotification(`Barang "${item.namaBarang}" berhasil disimpan ke cloud.`);
      } else {
        setItems((prev) => prev.filter((i) => i.id !== item.id));
        setNotification(`Gagal menyimpan "${item.namaBarang}" ke cloud. Periksa koneksi lalu coba lagi.`);
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleSaveItem = async (
    itemData: Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>,
    editId?: string
  ) => {
    const now = Date.now();
    let updatedTargetItem: InventoryItem | null = null;

    if (editId) {
      setItems((prev) =>
        prev.map((i) => {
          if (i.id === editId) {
            const updated = {
              ...i,
              ...itemData,
              updatedAt: now,
            };
            updatedTargetItem = updated;
            return updated;
          }
          return i;
        })
      );

      if (updatedTargetItem) {
        setIsSavingCloud(true);
        try {
          const ok = await saveItemToCloud(updatedTargetItem);
          if (ok) {
            setNotification(`Perubahan "${itemData.namaBarang}" disimpan ke cloud.`);
          } else {
            setNotification(`Gagal menyimpan perubahan "${itemData.namaBarang}". Memuat ulang data dari cloud...`);
            loadCloudData();
          }
        } finally {
          setIsSavingCloud(false);
        }
      }
    } else {
      const newItem: InventoryItem = {
        ...itemData,
        id: `item_${now}_${Math.random().toString(36).substring(2, 7)}`,
        createdAt: now,
        updatedAt: now,
        persentaseLabaDisimpanBulanan: itemData.persentaseLabaDisimpanBulanan ?? globalSavePercentMonthly,
      };
      setItems((prev) => [newItem, ...prev]);

      setIsSavingCloud(true);
      try {
        const ok = await saveItemToCloud(newItem);
        if (ok) {
          setNotification(`Barang "${newItem.namaBarang}" berhasil disimpan ke cloud.`);
        } else {
          setItems((prev) => prev.filter((i) => i.id !== newItem.id));
          setNotification(`Gagal menyimpan "${newItem.namaBarang}" ke cloud. Periksa koneksi lalu coba lagi.`);
        }
      } finally {
        setIsSavingCloud(false);
      }
    }

    setIsItemModalOpen(false);
    setEditingItem(null);
  };

  // Triggered by row delete icon
  const handleRequestDeleteItem = (id: string) => {
    const target = items.find((i) => i.id === id);
    if (target) {
      setItemToDelete(target);
    }
  };

  // Confirmed Delete execution (Fixed, works without window.confirm)
  const handleConfirmDeleteItem = async () => {
    if (!itemToDelete) return;
    const { id, namaBarang } = itemToDelete;

    // Optimistically update React state immediately
    setItems((prev) => prev.filter((i) => i.id !== id));
    setItemToDelete(null);

    // Hapus di Firestore
    setIsSavingCloud(true);
    try {
      const ok = await deleteItemFromCloud(id);
      if (ok) {
        setNotification(`Barang "${namaBarang}" berhasil dihapus dari cloud.`);
      } else {
        setNotification(`Gagal menghapus "${namaBarang}" dari cloud. Memuat ulang data...`);
        loadCloudData();
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  // Triggered by "Hapus Semua" toolbar button
  const handleRequestClearAll = () => {
    setIsConfirmClearAllOpen(true);
  };

  // Confirmed Clear All execution (Fixed, works without window.confirm)
  const handleConfirmClearAll = async () => {
    setIsConfirmClearAllOpen(false);
    setItems([]);

    setIsSavingCloud(true);
    try {
      const ok = await clearAllItemsFromCloud();
      if (ok) {
        setNotification('Seluruh data barang berhasil dikosongkan dari cloud.');
      } else {
        setNotification('Gagal mengosongkan data di cloud. Memuat ulang data...');
        loadCloudData();
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handleUpdateSoldQty = async (id: string, delta: number) => {
    let newQty = 0;
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          newQty = Math.min(
            item.jumlahBarangWadah,
            Math.max(0, item.jumlahBarangDijualSatuan + delta)
          );
          return {
            ...item,
            jumlahBarangDijualSatuan: newQty,
            updatedAt: Date.now(),
          };
        }
        return item;
      })
    );

    const ok = await updateItemInCloud(id, { jumlahBarangDijualSatuan: newQty });
    if (!ok) {
      setNotification('Gagal menyimpan jumlah terjual ke cloud. Memuat ulang data...');
      loadCloudData();
    }
  };

  const handleSetSoldQty = async (id: string, qty: number) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const clamped = Math.min(item.jumlahBarangWadah, Math.max(0, qty));
          return {
            ...item,
            jumlahBarangDijualSatuan: clamped,
            updatedAt: Date.now(),
          };
        }
        return item;
      })
    );

    const ok = await updateItemInCloud(id, { jumlahBarangDijualSatuan: qty });
    if (!ok) {
      setNotification('Gagal menyimpan jumlah terjual ke cloud. Memuat ulang data...');
      loadCloudData();
    }
  };

  const handleUpdateModalAwal = async (newModal: number) => {
    setModalAwal(newModal);
    const ok = await saveSettingsToCloud(newModal, globalSavePercentMonthly);
    setNotification(
      ok
        ? `Modal awal usaha Rp ${newModal.toLocaleString('id-ID')} disimpan ke cloud.`
        : 'Gagal menyimpan modal awal ke cloud. Periksa koneksi lalu coba lagi.'
    );
  };

  const handleRestoreData = async (rawItems: InventoryItem[], restoredModalAwal?: number) => {
    // Pastikan id valid & unik agar id di layar sama dengan id di Firestore
    const restoredItems = normalizeItems(rawItems);
    setItems(restoredItems);
    if (restoredModalAwal !== undefined && restoredModalAwal >= 0) {
      setModalAwal(restoredModalAwal);
    }

    setIsSavingCloud(true);
    try {
      const ok = await batchRestoreToCloud(restoredItems, restoredModalAwal ?? modalAwal, globalSavePercentMonthly);
      if (ok) {
        setNotification(`Data cadangan berhasil dipulihkan ke cloud (${restoredItems.length} barang).`);
      } else {
        setNotification('Gagal memulihkan cadangan ke cloud. Memuat ulang data...');
        loadCloudData();
      }
    } finally {
      setIsSavingCloud(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleImportSuccess = (
    importedItems: InventoryItem[], 
    newModal?: number, 
    mode: 'append' | 'replace' = 'append'
  ) => {
    if (typeof newModal === 'number' && newModal >= 0) {
      setModalAwal(newModal);
    }
    if (mode === 'replace') {
      setItems(importedItems);
    } else {
      setItems((prev) => {
        const incomingIds = new Set(importedItems.map(i => i.id));
        return [...importedItems, ...prev.filter(p => !incomingIds.has(p.id))];
      });
    }
    loadCloudData();
    setNotification(`Berhasil mengimpor ${importedItems.length} barang ke cloud!`);
  };

  return (
    <div className="relative min-h-screen flex flex-col text-slate-100 selection:bg-emerald-500/30 selection:text-emerald-200 font-sans">
      {/* Dynamic Cursor-Interactive Background (Bintang, Titik, Campuran Gambar Dagang Bergerak Sesuai Kursor) */}
      <CosmicInteractiveBackground
        currentTheme={backgroundTheme}
        onThemeChange={handleThemeChange}
      />

      {/* Main Foreground Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top Header with Navigation */}
        <Header
          activePage={activePage}
          onChangePage={setActivePage}
          itemsCount={items.length}
          onOpenAddModal={() => {
            setEditingItem(null);
            setIsItemModalOpen(true);
          }}
          onPrintReport={handlePrint}
          onOpenGuide={() => setIsGuideModalOpen(true)}
          onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
          isSyncingCloud={isSavingCloud}
        />

        {/* Dynamic Notification Toast */}
        {notification && (
          <div className="no-print bg-slate-900/90 backdrop-blur-md border-b border-emerald-500/30 px-4 py-2.5 text-xs text-emerald-200 animate-in fade-in">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-2 font-mono">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-medium">{notification}</span>
              </div>
              <button
                type="button"
                onClick={() => setNotification(null)}
                className="text-emerald-400 hover:text-emerald-100 font-bold cursor-pointer ml-4 p-1"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Gagal memuat data akun: tampilkan jelas agar tidak dikira data hilang */}
        {loadError && (
          <div className="no-print bg-rose-950/80 backdrop-blur-md border-b border-rose-500/40 px-4 py-2 text-xs text-rose-200">
            <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 font-mono">
              <span>{loadError}</span>
              <button
                type="button"
                onClick={() => loadCloudData()}
                className="shrink-0 px-3 py-1 rounded-lg bg-rose-500/20 border border-rose-400/40 text-rose-100 font-bold hover:bg-rose-500/30 cursor-pointer"
              >
                Coba lagi
              </button>
            </div>
          </div>
        )}

        {/* Main Container */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 sm:py-6">
          {/* PAGE 1: KASIR & INVENTORI */}
          {activePage === 'inventory' && (
            <div className="space-y-6">
              {/* Title & Quick Actions Strip */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 sm:p-5 bg-slate-900/80 backdrop-blur-xl rounded-2xl border border-slate-700/60 shadow-[0_20px_50px_rgba(0,0,0,0.4)]">
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px] font-mono font-bold tracking-wide">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      NIAGANOVA MATRIX
                    </span>
                    <h1 className="text-lg sm:text-xl font-extrabold tracking-tight text-white">
                      Pencatatan Arus Kas & Sisa Modal
                    </h1>
                    <span className="text-[11px] font-mono text-slate-400 font-medium">
                      · {currentRealTime}
                    </span>

                    {/* Firebase Firestore Database Badge */}
                    <div 
                      className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-emerald-950/70 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono font-semibold"
                      title="Penyimpanan cloud: Firebase Firestore, terpisah per akun"
                    >
                      <Database className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Firebase Cloud:</span>
                      <span className="text-white font-bold">
                        {loadError ? 'Gagal' : isCloudLoading ? 'Memuat' : 'Tersambung'}
                      </span>
                      <span className={`w-1.5 h-1.5 rounded-full ${loadError ? 'bg-rose-400' : 'bg-emerald-400 animate-ping'}`} />
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 font-sans">
                    Data tersimpan di cloud (Firebase) dan terpisah untuk setiap akun. Perhitungan sisa kas kasir real-time dan pemantauan perputaran modal usaha.
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto font-mono">
                  <button
                    type="button"
                    onClick={loadCloudData}
                    disabled={isCloudLoading}
                    title="Muat ulang data dari cloud"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl cursor-pointer transition-all shadow-xs disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isCloudLoading ? 'animate-spin' : ''}`} />
                    <span>{isCloudLoading ? 'Memuat...' : 'Refresh DB'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActivePage('reports')}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl cursor-pointer transition-all shadow-xs"
                    title="Buka laporan penjualan dan ekuitas usaha"
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Laporan & Ekuitas</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setActivePage('import')}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl cursor-pointer transition-all shadow-xs"
                    title="Impor file Excel atau CSV"
                  >
                    <UploadCloud className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Impor Data</span>
                  </button>
                </div>
              </div>

              {/* Rolling Cash Balance & Capital Cards Focusing on Sisa Kas */}
              <SummaryCards
                summary={summary}
                modalAwal={modalAwal}
                onUpdateModalAwal={handleUpdateModalAwal}
                onOpenGuide={() => setIsGuideModalOpen(true)}
                currentRealTime={currentRealTime}
                bulanFilter={selectedMonth}
              />

              {/* Quick Add Bar */}
              <QuickAddBar
                onAdd={handleAddItem}
                globalSavePercentMonthly={globalSavePercentMonthly}
              />

              {/* Main Table with Numeric Sold Input, Sisa Kas & Real-Time Timestamps */}
              <InventoryTable
                items={items}
                modalAwal={modalAwal}
                onEditItem={(item) => {
                  setEditingItem(item);
                  setIsItemModalOpen(true);
                }}
                onDeleteItem={handleRequestDeleteItem}
                onUpdateSoldQty={handleUpdateSoldQty}
                onSetSoldQty={handleSetSoldQty}
                onClearAll={handleRequestClearAll}
                selectedMonth={selectedMonth}
                onSelectMonth={setSelectedMonth}
              />
            </div>
          )}

          {/* PAGE 2: LAPORAN PENJUALAN & EKUITAS */}
          {activePage === 'reports' && (
            <ReportsEquityPage
              items={items}
              modalAwal={modalAwal}
              summary={summary}
              selectedMonth={selectedMonth}
              onSelectMonth={setSelectedMonth}
              onPrintReport={handlePrint}
            />
          )}

          {/* PAGE 3: IMPOR DATA (EXCEL / CSV / JSON) */}
          {activePage === 'import' && (
            <ImportDataPage
              currentItemsCount={items.length}
              currentModalAwal={modalAwal}
              currentItems={items}
              onImportSuccess={handleImportSuccess}
              onNavigateToInventory={() => setActivePage('inventory')}
            />
          )}
        </main>

        {/* Footer */}
        <footer className="no-print mt-auto border-t border-slate-800/80 bg-slate-950/80 backdrop-blur-xl py-5 text-center text-xs text-slate-400">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2.5 font-mono text-[11px]">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
              <span className="text-slate-300 font-semibold tracking-wide">NiagaNova Matrix</span>
              <span className="text-slate-600">·</span>
              <span>Kalkulator Dagang & Arus Kas Real-time</span>
            </div>
            <div className="flex items-center gap-2 text-slate-400">
              <Database className="w-3.5 h-3.5 text-emerald-400" />
              <span>Database: <strong className="text-emerald-400">Firebase Firestore</strong></span>
            </div>
          </div>
        </footer>

        {/* Modals */}
        <ItemModal
          isOpen={isItemModalOpen}
          onClose={() => {
            setIsItemModalOpen(false);
            setEditingItem(null);
          }}
          onSave={handleSaveItem}
          editingItem={editingItem}
        />

        <CashFlowGuideModal
          isOpen={isGuideModalOpen}
          onClose={() => setIsGuideModalOpen(false)}
        />

        <DownloadModal
          isOpen={isDownloadModalOpen}
          onClose={() => setIsDownloadModalOpen(false)}
          items={items}
          modalAwal={modalAwal}
          summary={summary}
          onRestoreData={handleRestoreData}
          onOpenAuthModal={() => setIsAuthModalOpen(true)}
        />

        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
        />

        {/* Dedicated Delete Confirmation Modal (Reliable, no window.confirm) */}
        <DeleteConfirmModal
          isOpen={!!itemToDelete}
          onClose={() => setItemToDelete(null)}
          onConfirm={handleConfirmDeleteItem}
          item={itemToDelete}
          mode="single"
        />

        {/* Dedicated Clear All Confirmation Modal */}
        <DeleteConfirmModal
          isOpen={isConfirmClearAllOpen}
          onClose={() => setIsConfirmClearAllOpen(false)}
          onConfirm={handleConfirmClearAll}
          mode="all"
        />

        {/* Print View Component */}
        <PrintReportView
          items={filteredMonthlyItems}
          summary={summary}
          modalAwal={modalAwal}
        />
      </div>
    </div>
  );
}

/**
 * Gerbang login: data hanya ditampilkan untuk akun yang sudah login.
 * key={user.uid} membuat seluruh state aplikasi di-reset saat akun berganti,
 * sehingga data satu akun tidak pernah terbawa ke akun lain di perangkat yang sama.
 */
export default function App() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-slate-300 font-mono text-sm">
        Memeriksa sesi login...
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950">
        <AuthModal isOpen required />
      </div>
    );
  }

  return <AppContent key={user.uid} />;
}
