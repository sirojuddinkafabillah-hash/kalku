import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { InventoryItem } from '../types/inventory';
import { toItemDoc, fromItemDoc, toItemPatch, chunk, isValidItemId } from './itemMapper';

/**
 * Penyimpanan cloud: Firebase Firestore, terpisah per akun.
 *   users/{uid}            -> pengaturan (modalAwal, globalSavePercentMonthly, email)
 *   users/{uid}/items/{id} -> barang
 * Keamanan ditegakkan oleh firestore.rules (hanya pemilik uid yang bisa membaca/menulis).
 * UID selalu diambil dari sesi login Firebase, bukan dari input pengguna.
 */

export interface CloudInventory {
  items: InventoryItem[];
  modalAwal: number;
  globalSavePercentMonthly: number;
}

const WRITE_TIMEOUT_MS = 20000;
const DEFAULT_MODAL = 50000;
const DEFAULT_SAVE_PERCENT = 50;

function currentUser() {
  const u = auth.currentUser;
  if (!u) throw new Error('Anda belum login. Silakan login terlebih dahulu.');
  return u;
}

// Terjemahkan error Firebase menjadi pesan yang mudah dipahami
export function friendlyFirestoreError(err: unknown): string {
  const code = (err as any)?.code as string | undefined;
  switch (code) {
    case 'permission-denied':
      return 'Akses ditolak oleh aturan keamanan Firestore. Pastikan firestore.rules sudah dipublikasikan ke database yang benar dan Anda sudah login.';
    case 'unauthenticated':
      return 'Sesi login tidak valid. Silakan login ulang.';
    case 'unavailable':
    case 'deadline-exceeded':
      return 'Tidak dapat terhubung ke server Firestore. Periksa koneksi internet Anda.';
    case 'not-found':
      return 'Database Firestore tidak ditemukan. Periksa firestoreDatabaseId di firebase-applet-config.json.';
    case 'resource-exhausted':
      return 'Kuota Firestore harian habis. Coba lagi besok atau tingkatkan paket Firebase.';
    default:
      return err instanceof Error ? err.message : 'Terjadi kesalahan saat mengakses penyimpanan cloud.';
  }
}

// Saat offline, promise tulis Firestore bisa menggantung: beri batas waktu agar UI tidak macet.
function withTimeout<T>(p: Promise<T>, ms = WRITE_TIMEOUT_MS): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(Object.assign(new Error('Waktu habis'), { code: 'deadline-exceeded' })), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

const itemsCol = (uid: string) => collection(db, 'users', uid, 'items');
const itemRef = (uid: string, id: string) => doc(db, 'users', uid, 'items', id);
const userRef = (uid: string) => doc(db, 'users', uid);

// Profil wajib memuat userId, email, modalAwal (lihat firestore.rules)
function profileBase(uid: string, email: string | null, modalAwal: number) {
  return { userId: uid, email: email ?? '', modalAwal, updatedAt: new Date().toISOString() };
}

// 1. Ambil semua barang & pengaturan milik akun yang login
export async function fetchInventoryFromCloud(): Promise<CloudInventory> {
  try {
    const u = currentUser();
    const [snap, profileSnap] = await Promise.all([getDocs(itemsCol(u.uid)), getDoc(userRef(u.uid))]);
    const items: InventoryItem[] = [];
    snap.forEach((d) => items.push(fromItemDoc(d.data(), d.id)));
    items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const p: any = profileSnap.exists() ? profileSnap.data() : {};
    return {
      items,
      modalAwal: typeof p.modalAwal === 'number' ? p.modalAwal : DEFAULT_MODAL,
      globalSavePercentMonthly:
        typeof p.globalSavePercentMonthly === 'number' ? p.globalSavePercentMonthly : DEFAULT_SAVE_PERCENT,
    };
  } catch (err) {
    console.error('[Cloud] Gagal memuat data:', err);
    throw new Error(friendlyFirestoreError(err));
  }
}

// 2. Simpan / upsert satu barang
export async function saveItemToCloud(item: InventoryItem): Promise<boolean> {
  try {
    const u = currentUser();
    await withTimeout(setDoc(itemRef(u.uid, item.id), toItemDoc(item, u.uid)));
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal menyimpan barang:', err);
    return false;
  }
}

// 3. Update sebagian field satu barang
export async function updateItemInCloud(id: string, patch: Partial<InventoryItem>): Promise<boolean> {
  try {
    const u = currentUser();
    if (!isValidItemId(id)) return false;
    await withTimeout(updateDoc(itemRef(u.uid, id), toItemPatch(patch)));
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal memperbarui barang:', err);
    return false;
  }
}

// 4. Hapus satu barang
export async function deleteItemFromCloud(id: string): Promise<boolean> {
  try {
    const u = currentUser();
    if (!isValidItemId(id)) return false;
    await withTimeout(deleteDoc(itemRef(u.uid, id)));
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal menghapus barang:', err);
    return false;
  }
}

// Hapus banyak dokumen per batch (maks 500 operasi per batch)
async function deleteItemsByIds(uid: string, ids: string[]) {
  for (const part of chunk(ids)) {
    const batch = writeBatch(db);
    part.forEach((id) => batch.delete(itemRef(uid, id)));
    await withTimeout(batch.commit(), WRITE_TIMEOUT_MS * 2);
  }
}

// 5. Hapus semua barang milik akun ini
export async function clearAllItemsFromCloud(): Promise<boolean> {
  try {
    const u = currentUser();
    const snap = await getDocs(itemsCol(u.uid));
    await deleteItemsByIds(u.uid, snap.docs.map((d) => d.id));
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal mengosongkan data:', err);
    return false;
  }
}

// 6. Simpan pengaturan (Modal Awal & Save %)
export async function saveSettingsToCloud(modalAwal?: number, globalSavePercentMonthly?: number): Promise<boolean> {
  try {
    const u = currentUser();
    const data: Record<string, unknown> = { userId: u.uid, email: u.email ?? '', updatedAt: new Date().toISOString() };
    if (typeof modalAwal === 'number' && Number.isFinite(modalAwal)) data.modalAwal = modalAwal;
    if (typeof globalSavePercentMonthly === 'number' && Number.isFinite(globalSavePercentMonthly)) {
      data.globalSavePercentMonthly = globalSavePercentMonthly;
    }
    // Dokumen baru wajib punya modalAwal (aturan Firestore)
    if (data.modalAwal === undefined) {
      const existing = await getDoc(userRef(u.uid));
      if (!existing.exists()) data.modalAwal = DEFAULT_MODAL;
    }
    await withTimeout(setDoc(userRef(u.uid), data, { merge: true }));
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal menyimpan pengaturan:', err);
    return false;
  }
}

// Tulis banyak barang (upsert) per batch
async function upsertItems(uid: string, items: InventoryItem[]) {
  for (const part of chunk(items)) {
    const batch = writeBatch(db);
    part.forEach((it) => batch.set(itemRef(uid, it.id), toItemDoc(it, uid)));
    await withTimeout(batch.commit(), WRITE_TIMEOUT_MS * 2);
  }
}

// Ganti seluruh data: tulis data BARU dulu, baru hapus yang lama (tidak ada momen data hilang jika gagal di tengah)
async function replaceAll(uid: string, items: InventoryItem[]) {
  const existing = await getDocs(itemsCol(uid));
  await upsertItems(uid, items);
  const keep = new Set(items.map((i) => i.id));
  const stale = existing.docs.map((d) => d.id).filter((id) => !keep.has(id));
  await deleteItemsByIds(uid, stale);
}

// 7. Pulihkan cadangan (ganti seluruh data akun ini)
export async function batchRestoreToCloud(
  items: InventoryItem[],
  modalAwal: number,
  globalSavePercentMonthly: number = DEFAULT_SAVE_PERCENT
): Promise<boolean> {
  try {
    const u = currentUser();
    await replaceAll(u.uid, items);
    await withTimeout(
      setDoc(userRef(u.uid), { ...profileBase(u.uid, u.email, modalAwal), globalSavePercentMonthly }, { merge: true })
    );
    return true;
  } catch (err) {
    console.error('[Cloud] Gagal memulihkan cadangan:', err);
    return false;
  }
}

// 8. Impor massal (mode 'append' atau 'replace')
export async function importItemsToCloud(
  items: InventoryItem[],
  mode: 'append' | 'replace' = 'append',
  modalAwal?: number
): Promise<{ success: boolean; message: string; count?: number }> {
  try {
    const u = currentUser();
    if (items.length > 5000) {
      return { success: false, message: 'Maksimal 5000 barang per impor.' };
    }
    const bad = items.find((i) => !isValidItemId(i.id));
    if (bad) {
      return { success: false, message: `ID barang tidak valid: "${String(bad.id).slice(0, 40)}"` };
    }

    if (mode === 'replace') await replaceAll(u.uid, items);
    else await upsertItems(u.uid, items);

    if (typeof modalAwal === 'number' && Number.isFinite(modalAwal) && modalAwal >= 0) {
      await withTimeout(setDoc(userRef(u.uid), profileBase(u.uid, u.email, modalAwal), { merge: true }));
    }
    return { success: true, message: `Berhasil mengimpor ${items.length} barang ke Firebase Firestore`, count: items.length };
  } catch (err) {
    console.error('[Cloud] Gagal mengimpor:', err);
    return { success: false, message: friendlyFirestoreError(err) };
  }
}
