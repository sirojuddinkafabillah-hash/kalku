import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  firebaseSignOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  sendEmailVerification,
  User,
} from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithGoogle: () => Promise<User>;
  signInWithEmail: (email: string, pass: string) => Promise<User>;
  signUpWithEmail: (email: string, pass: string) => Promise<User>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * Login SEPENUHNYA dari Firebase Auth. Tidak ada "sesi lokal" buatan sendiri:
 * pengguna hanya dianggap login jika Firebase menyatakan demikian, dan sesi itulah yang
 * dipakai aturan Firestore (request.auth.uid) untuk menentukan pemilik data.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Bersihkan sisa sesi lokal lama (versi sebelumnya menyimpan "sesi" palsu di localStorage)
    try {
      localStorage.removeItem('niaganova_auth_user_session');
    } catch {
      /* ignore */
    }
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async (): Promise<User> => {
    const res = await signInWithPopup(auth, googleProvider);
    return res.user;
  };

  const signInWithEmail = async (email: string, pass: string): Promise<User> => {
    const res = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), pass);
    return res.user;
  };

  const signUpWithEmail = async (email: string, pass: string): Promise<User> => {
    const res = await createUserWithEmailAndPassword(auth, email.trim().toLowerCase(), pass);
    // Kirim email verifikasi (gagal mengirim tidak boleh membatalkan pendaftaran)
    try {
      await sendEmailVerification(res.user);
    } catch (e) {
      console.warn('Gagal mengirim email verifikasi:', e);
    }
    return res.user;
  };

  const resetPassword = async (email: string): Promise<void> => {
    await sendPasswordResetEmail(auth, email.trim().toLowerCase());
  };

  const logout = async () => {
    await firebaseSignOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signInWithEmail, signUpWithEmail, resetPassword, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
