# Perbaikan: "Gagal menyimpan ke MongoDB Atlas: Unexpected token 'T'..."

## Penyebab
Backend Express hanya jalan lewat `server.ts` (lokal/AI Studio). Di Vercel hanya frontend statis yang
ter-deploy, jadi `/api/...` membalas halaman 404 ("The page could not be found") dan frontend gagal
mem-parse-nya sebagai JSON.

## Yang diubah
- `api/index.ts` (baru): seluruh backend Express + koneksi MongoDB, diekspor sebagai Vercel Function.
- `vercel.json` (baru): mengarahkan `/api/*` ke function tersebut.
- `server.ts`: sekarang hanya server lokal (memakai app dari `api/index.ts` + Vite).
- `src/server/mongodb.ts`: DIHAPUS. File ini berisi password MongoDB yang tertulis langsung di kode.
- `src/services/mongoApi.ts`: respon non-JSON kini menghasilkan pesan error yang jelas.
- Endpoint tulis kini membalas 503 + alasan jika database belum terhubung (sebelumnya pura-pura sukses).
- `.env.example`: diperbarui.

## Langkah wajib setelah upload ke GitHub
1. **Ganti password database user MongoDB Atlas** (Database Access > Edit > Edit Password).
   Password lama sudah pernah ada di kode GitHub, anggap sudah bocor.
2. Vercel > Project > Settings > Environment Variables: tambahkan `MONGODB_URI` (URI baru dengan password baru),
   opsional `MONGODB_DB_NAME` (default `niaganova_db`).
3. MongoDB Atlas > Network Access: izinkan `0.0.0.0/0`.
4. Commit + push, atau Redeploy di Vercel (env baru baru berlaku setelah redeploy).
5. Cek `https://DOMAIN-ANDA/api/db/status`: harus menampilkan `"connected": true`.
